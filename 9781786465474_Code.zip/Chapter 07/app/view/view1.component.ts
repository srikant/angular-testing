import {Component} from '@angular/core';

@Component({
  selector: 'app-view1',
  template: '<div id="view1">I am view one component</div>'
})
export class View1Component {

}
