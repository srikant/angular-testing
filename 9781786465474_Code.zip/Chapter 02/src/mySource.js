
var a,
myObj = {
	 setA: function(value) {
			 a = value;
	 },
	 getA: function(value) {
			 return a;
	 },
};
