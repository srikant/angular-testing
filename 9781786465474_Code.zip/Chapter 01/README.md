# Angular TDD Chapter1 Source

This repository is for 2 simple test projects.

1. Simple calculator testing
2. Builder pattern
