interface User {
  locationId: number;
  name: string;
}